class Project:
    projectName = "PuzzlingClarity"