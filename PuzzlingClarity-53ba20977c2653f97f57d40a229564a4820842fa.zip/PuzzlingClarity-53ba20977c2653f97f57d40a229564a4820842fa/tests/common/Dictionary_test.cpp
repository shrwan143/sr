#define BOOST_TEST_MODULE Dictionary
#include <boost/test/unit_test.hpp>

#include "Common/Dictionary.hpp"

#include <algorithm>

BOOST_AUTO_TEST_SUITE(Dictionary_tests)

BOOST_AUTO_TEST_CASE(basic_test)
{
    
}

BOOST_AUTO_TEST_SUITE_END()
