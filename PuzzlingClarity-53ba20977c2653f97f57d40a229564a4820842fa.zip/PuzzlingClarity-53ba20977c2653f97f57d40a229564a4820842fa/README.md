# Almost everything in this repo is explained in the youtube channel  https://www.youtube.com/channel/UCmaGePaRecLjqZKHtGVY83w/


# Prerequisites

## Tools and libraries

1. Cmake 
2. clang++ (optional, works with g++ as well)
3. Boost >= 1.50
4. Python 3

## Configs

PCPATH should direct to sources directory
PCBUILDPATH should direct to the builded directory
PYTHONPATH += PCPATH + /python/lib

## Namings
  mysql database name is pc , type utf8-general-ci
