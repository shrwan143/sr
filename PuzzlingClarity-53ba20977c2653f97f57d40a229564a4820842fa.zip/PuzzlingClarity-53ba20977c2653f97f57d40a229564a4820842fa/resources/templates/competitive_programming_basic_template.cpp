#include <iostream>
#include <cstdio>
#include <fstream>
#include <vector>
#include <string>
#include <stack>
#include <queue>
#include <map>
#include <set>
#include <unordered_map>
#include <unordered_set>
#include <algorithm>
#include <cctype>
#include <cmath>

using namespace std;
using ll=long long;
using ull = unsigned long long;


int main()
{
	return 0;
}
