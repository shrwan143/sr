int centuryFromYear(int year) {
    return std::ceil(static_cast<float>(year) / 100);
}
