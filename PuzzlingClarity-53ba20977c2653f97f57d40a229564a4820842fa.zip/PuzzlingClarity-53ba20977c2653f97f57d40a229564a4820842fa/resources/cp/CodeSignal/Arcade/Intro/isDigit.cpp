bool isDigit(char symbol) 
{
    return std::isdigit(symbol);
}
