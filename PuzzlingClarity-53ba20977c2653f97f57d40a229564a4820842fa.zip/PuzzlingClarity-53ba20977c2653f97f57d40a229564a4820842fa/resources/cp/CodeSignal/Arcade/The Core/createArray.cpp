std::vector<int> createArray(int size) 
{
    return std::vector<int>(size, 1);
}
