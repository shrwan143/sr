std::string encloseInBrackets(std::string inputString) 
{
    return "(" + inputString + ")";
}
