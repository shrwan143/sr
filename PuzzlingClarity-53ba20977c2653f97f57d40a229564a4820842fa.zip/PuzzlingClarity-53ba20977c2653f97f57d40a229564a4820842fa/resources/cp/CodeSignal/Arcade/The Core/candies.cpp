int candies(int n, int m) 
{
    return (m / n) * n;
}
