bool reachNextLevel(int experience, int threshold, int reward) 
{
    return (experience + reward) >= threshold;
}
