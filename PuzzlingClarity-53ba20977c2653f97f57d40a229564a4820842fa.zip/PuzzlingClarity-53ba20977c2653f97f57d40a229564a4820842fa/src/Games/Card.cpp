#include "Games/Card.hpp"

namespace pc {
namespace Games {

constexpr std::array<Card::Suit, 4> Card::commonSuits;
constexpr std::array<Card::Value, 13> Card::commonValues;


}
}
