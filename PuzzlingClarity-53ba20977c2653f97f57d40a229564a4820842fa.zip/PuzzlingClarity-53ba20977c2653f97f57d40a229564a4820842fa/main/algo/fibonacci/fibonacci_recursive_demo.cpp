#include "algo/fibonacci.hpp"
#include "io/io.hpp"

int main()
{
    pc::algo::fib_rec(20);
}