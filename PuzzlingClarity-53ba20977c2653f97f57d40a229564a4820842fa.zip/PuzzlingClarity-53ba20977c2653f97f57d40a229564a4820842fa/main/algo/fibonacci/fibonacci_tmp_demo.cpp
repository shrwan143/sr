#include "algo/fibonacci.hpp"

int main()
{
    pc::algo::fib_tmp<20>::val;
    return 0;
}