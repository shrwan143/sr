#include "algo/DateAndTime.hpp"
#include "algo/Grids.hpp"
#include "algo/Numbers.hpp"
#include "algo/Strings.hpp"
#include "algo/Trie.hpp"

#include <iostream>

int main()
{
    std::cout << "New Beginning" << std::endl;
    return 0;
}