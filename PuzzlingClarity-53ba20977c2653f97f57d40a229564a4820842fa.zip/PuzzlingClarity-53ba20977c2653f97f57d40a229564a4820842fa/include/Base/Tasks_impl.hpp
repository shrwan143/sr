#pragma once 

namespace pc {
namespace base {



/// slugs are used everywhere aren't day
inline std::string task_slug(Task t);
}
}