
namespace pc {
namespace Generators {

/// high quality random number in range
int random_number(int left, int right);

}
}
