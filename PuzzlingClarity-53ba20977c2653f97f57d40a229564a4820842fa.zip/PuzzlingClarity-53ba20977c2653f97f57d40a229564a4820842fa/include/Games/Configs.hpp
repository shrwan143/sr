#pragma once


// This file is just a combination of all Game configs
#include "Games/AndharBahar/Configs.hpp"
#include "Games/Card32/Configs.hpp"

