#pragma once

namespace pc {
namespace algo {
    
/// checks if the given year is a leap year
bool is_leap(int y);

}
}
